if(window.PaymentRequest){
 const supportedPaymentMethods = [
     {
         supportedMethods : ['basic-card']
     }
 ];
 const Paymentdetails ={
     total:{
         label:'Total cost',
         amount:{
             currency:'USD',
             value: 0
         }
     }
 }

 const options = {
  
    requestPayerPhone: true,
    shippingType: 'delivery'
  };

 const paymentRequest = new PaymentRequest(
     supportedPaymentMethods,Paymentdetails,options
 );

    paymentRequest.show()
    .then(payment => console.log(payment))
    .catch(error => console.log(error));
    ;

   
}else{
console.log("not");
}