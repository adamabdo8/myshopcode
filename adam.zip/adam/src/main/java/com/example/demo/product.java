package com.example.demo;


import java.io.Serializable;
import java.util.ArrayList;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity(name="product")
@Table(name="product")
@JsonIgnoreProperties(ignoreUnknown = true)
public class product implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id  ;
	@Column
	private String category;
	@Column
	private String productname;
	@Column
	private String productdescribtion;
	@Column
	private int price;


	

	
	public int getPrice() {
		return price;
	}





	public void setPrice(int price) {
		this.price = price;
	}





	public String getProductdescribtion() {
		return productdescribtion;
	}





	public void setProductdescribtion(String productdescribtion) {
		this.productdescribtion = productdescribtion;
	}





	public product() {}




















	public int getId() {
		return id;
	}





	public void setId(int id) {
		this.id = id;
	}











	public String getCategory() {
		return category;
	}





	public void setCategory(String category) {
		this.category = category;
	}










	public String getProductname() {
		return productname;
	}





	public void setProductname(String productname) {
		this.productname = productname;
	}





	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
}
