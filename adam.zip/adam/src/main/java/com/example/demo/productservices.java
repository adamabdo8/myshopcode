package com.example.demo;

import java.awt.print.Pageable;
import java.util.Collection;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;

import com.example.demo.user;
import com.sun.istack.Nullable;
@Service
@Transactional
public class productservices {
	@Autowired
	private productDao dao;
	public product saveproduct(product u)
	{
	return dao.save(u);
	}
	
	public Collection<product> getAllproductss()
	{
		return dao.findAll();
	}
	public void removepeoduct(int id )
	{
		dao.deleteById(id);
	}
	
}











