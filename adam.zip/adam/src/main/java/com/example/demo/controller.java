package com.example.demo;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
public class controller {
	
	@Autowired
	userService udao;
	@Autowired
	productservices pdao;

	@PostMapping(value="/createaccount")
	public ArrayList<String> createaccount(@RequestBody user usr) {
		ArrayList<String> list = new ArrayList<String> ();
		if(!usr.getPassword().equals(usr.getPassword2())) {
			list.add("the passwords douesnt match");
			return list;
		}
		if(usr.getPassword().length()<8) {
			list.add( "the password have to be more than 8 chars");
			return list;
		}
		if(!isValidEmailAddress(usr.getEmail())) {
			list.add( "the email is invalid");
			return list;
		}

		Object[] userarray = udao.getAllUsers().toArray();
		for (int i = 0; i < userarray.length; i++) {
			if(usr.getEmail().equals(((user) userarray[i]).getEmail())) {
				list.add("there is an account with this email");
			return list;
			
			}
		}	
		list.add("true");
		list.add(usr.getEmail());
		udao.saveUser(usr);
		return list;
	}
	
    public static boolean isValidEmailAddress(String email) {
        String ePattern = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(ePattern);
        java.util.regex.Matcher m = p.matcher(email);
        return m.matches();
 }
    

	@PostMapping(
			  value = "/login")
	public ArrayList<String>  login(@RequestBody user usr){	
		ArrayList<String> loginerrors = new ArrayList<String>();
		int indexofemail = -1;
		Object[] userarray = udao.getAllUsers().toArray();
		for (int i = 0; i < userarray.length; i++) {
			if(usr.getEmail().equals(((user) userarray[i]).getEmail())) {
				indexofemail=i;		
				break;
			}
		}	
		if(indexofemail==-1) {
			loginerrors.add("this email doesnt exist");
		}
		else if(!(usr.getPassword()).equals(((user) userarray[indexofemail]).getPassword()))
		
		{
			loginerrors.add("the password is wrong");
		}
		if(loginerrors.size()==0) {
			loginerrors.add("true");
			loginerrors.add(usr.getEmail());
		
		}
		
		
	
		return loginerrors;		
	}
	

	@PostMapping(
			  value = "/updatepassword")
	public ArrayList<String>  updatepassword(@RequestBody user usr){	
		ArrayList<String> loginerrors = new ArrayList<String>();
		int indexofemail = -1;
		Object[] userarray = udao.getAllUsers().toArray();
		for (int i = 0; i < userarray.length; i++) {
			if(usr.getEmail().equals(((user) userarray[i]).getEmail())) {
				indexofemail=i;		
				break;
			}
		}	
		if(indexofemail==-1) {
			loginerrors.add("this email doesnt exist");
		}
		else if(!(usr.getPassword()).equals(((user) userarray[indexofemail]).getPassword()))
		
		{
			loginerrors.add("the password is wrong");
		}
		if(usr.getPassword2().length()<8) {
			loginerrors.add("the password have to be more than 8 chars");
		}
		if(loginerrors.size()==0) {
			user nsr = (user) userarray[indexofemail];
			nsr.setPassword(usr.getPassword2());
			nsr.setPassword2(usr.getPassword2());
			udao.saveUser(nsr);
			loginerrors.add("true");
	
			
		}
		
		
	
		return loginerrors;		
	}
	
	 @PostMapping("/uploadimage")
	    public ArrayList<String> img(
	    		@RequestParam("files") MultipartFile img,
	    		@RequestParam("files2") MultipartFile img2,
	    		@RequestParam("files3") MultipartFile img3,
	    		@RequestParam("files4") MultipartFile img4,
	    		@RequestParam("files5") MultipartFile img5,
	    		@RequestParam("productname") String productname,
	    		@RequestParam("productdescribtion") String productdescription,
	    		@RequestParam("cats") String cats,
	    		@RequestParam("price") int price
	    		)

	    				throws IOException {
	    	ArrayList<String> uploadproblems = new ArrayList<String>(); 
	    	product p = new product();
	   
	       	
	       	Object[] userarray = pdao.getAllproductss().toArray();
			for (int i = 0; i < userarray.length; i++) {
				if( productname.equals(((product) userarray[i]).getProductname() )) {
					uploadproblems.add("this product alreeady exists or an product with this name");
					return uploadproblems;
				}
			}
					
			String folder = "C:\\Users\\User\\Desktop\\neu\\adam\\src\\main\\resources\\static\\images\\";	   
			byte[] bit1 = img.getBytes();
	    	Path path1 = Paths.get(folder + productname+"_0.png");
	    	Files.write(path1, bit1);	
	    	 bit1 = img2.getBytes();
	    	 path1 = Paths.get(folder + productname+"_1.png");
	    	 Files.write(path1, bit1);		
	    	 bit1 = img3.getBytes();
	    	 path1 = Paths.get(folder + productname+"_2.png");
	    	 Files.write(path1, bit1);		
	    	 bit1 = img4.getBytes();
	    	 path1 = Paths.get(folder + productname+"_3.png");
	    	 Files.write(path1, bit1);		
	    	 bit1 = img5.getBytes();
	    	 path1 = Paths.get(folder + productname+"_4.png");
	    	 Files.write(path1, bit1);		
		       	p.setCategory(cats); 
		       	p.setProductname(productname);   
		       	p.setProductdescribtion(productdescription);	
		       	p.setPrice(price);
		       	pdao.saveproduct(p);
		       	uploadproblems.add("true");
		    	return uploadproblems;
		 	   
			}
	 
	    
	 
	 @PostMapping("/getallproducts")
	    public ArrayList<product> getproducts(
	    		@RequestParam("count") int count,
	    		@RequestParam("word") String word,
	    		@RequestParam("categorie") String categorie
	    		)

	    {
	    	ArrayList<product> returnvalue = new ArrayList<product>();
		 Object[] allproducts =  pdao.getAllproductss().toArray();
		 
		 for (int i = 0; i < allproducts.length || i == count; i++) {
			 
			 returnvalue.add((product)allproducts[i]); 		
			 
		}
	return returnvalue;
		 
		 
		 	   
			}
	 
	    

		 @PostMapping("/getproductbyid")
		    public ArrayList<product> getproductbyid(
		    		@RequestParam("id") int id
		    	
		    		)

		    {
		    	ArrayList<product> returnvalue = new ArrayList<product>();
			 Object[] allproducts =  pdao.getAllproductss().toArray();
			 
			 for (int i = 0; i < allproducts.length; i++) {
				 
				 if(((product) allproducts[i]).getId()==id) {
					 returnvalue.add((product)allproducts[i]);
					 return returnvalue;
					 
				 }
				 
			}
		return returnvalue;
			 
			 
			 	   
				}
		    
		    
		    
		    
		    
		    
		    
		    @PostMapping("/getproductbycategory")
		    public ArrayList<product> getproductbycategory(
		    		@RequestParam("categorie") String categorie
		    	
		    		)

		    {
		    	ArrayList<product> returnvalue = new ArrayList<product>();
			 Object[] allproducts =  pdao.getAllproductss().toArray();
			 
			 for (int i = 0; i < allproducts.length || i == 500; i++) {
				 
				 if(((product) allproducts[i]).getCategory().equals(categorie)) {
					 returnvalue.add((product)allproducts[i]);
					
					 
				 }
				 
			}
		return returnvalue;
			 
			 
			 	   
				}
	 
		    
		    

		    
		    
		    
		    
		    @PostMapping("/getproductbysearch")
		    public ArrayList<product> getproductbysearch(
		    		@RequestParam("search") String search
		    	
		    		)

		    {
		    	ArrayList<product> returnvalue = new ArrayList<product>();
			 Object[] allproducts =  pdao.getAllproductss().toArray();
			 
			 ArrayList<points> pointss = new ArrayList<points>();
			 for (int i = 0; i < allproducts.length; i++) {
				 pointss.add(new points(0,0));
			}
			 if(search.contains("+")) {
				search= search.replace("+", " ");
			 }
			 System.out.println(search);
			 String[] searches = search.split(" ");
			 for (int i = 0; i < allproducts.length; i++) {
				 
				 for (int j = 0; j < searches.length; j++) {
					 
					 if(((product) allproducts[i]).getProductname().equals(searches[j])) {
						 pointss.set(i,new points(pointss.get(i).getPoints()+6,i));
					 	}
					 
					 if(((product) allproducts[i]).getProductname().contains(searches[j])) {
						 pointss.set(i,new points(pointss.get(i).getPoints()+5,i));
					 	}
					 if(((product) allproducts[i]).getCategory().contains(searches[j])) {
						 pointss.set(i,new points(pointss.get(i).getPoints()+3,i));
					 	}
					 if(((product) allproducts[i]).getCategory().equals(searches[j])) {
						 pointss.set(i,new points(pointss.get(i).getPoints()+8,i));
					 	}
					 
					 if(((product) allproducts[i]).getProductdescribtion().contains(searches[j])) {
						 pointss.set(i,new points(pointss.get(i).getPoints()+4,i));
					 	}
				}

			}
			 

			 
			 ArrayList<product> newitems = new ArrayList<product>();
				
				Collections.sort(pointss, new Comparator<points>(){
					   public int compare(points o1, points o2){
					      return o1.getPoints() - o2.getPoints();
					   }
					});
				Collections.sort(pointss, (o1, o2) -> o1.getPoints() - o2.getPoints());
				Collections.reverse(pointss);
//				for (int i = 0; pointss.get(i).getPoints()>1; i++) {
//				newitems.add((product) allproducts[pointss.get(i).getMainindes()]);
//				}
			
				 for (int i = 0; i < pointss.size(); i++) {
					if(pointss.get(i).getPoints()>1) {
						returnvalue.add((product) allproducts[pointss.get(i).getMainindes()]);
					}
				}	
				
			return returnvalue;
			 
	
		    }
		    
		    
		    
		    
		    
		    
		    
		    
	 
	 
	  
	    
		@PostMapping(
				  value = "/deleteproduct")
		public 	ArrayList<String> delteproduct(@RequestBody user usr){	
			ArrayList<String> shopdeleteerrors = new ArrayList<String>();
		
		pdao.removepeoduct(usr.getId());
		
		
		return shopdeleteerrors;

		}
	    
	    
	    
	    
	}
	
	
	

