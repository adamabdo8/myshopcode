package com.example.demo;

public class points {

	int points;
	int mainindes;
	@Override
	public String toString() {
		return "points [points=" + points + ", mainindes=" + mainindes + "]";
	}
	public points(int points, int mainindes) {
		super();
		this.points = points;
		this.mainindes = mainindes;
	}
	public int getPoints() {
		return points;
	}
	public void setPoints(int points) {
		this.points = points;
	}
	public int getMainindes() {
		return mainindes;
	}
	public void setMainindes(int mainindes) {
		this.mainindes = mainindes;
	}
	
}
